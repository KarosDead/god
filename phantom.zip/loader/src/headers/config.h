#pragma once

#define HTTP_SERVER "10.56.130.205"
#define HTTP_PORT 80

#define TFTP_SERVER "10.56.130.205"
